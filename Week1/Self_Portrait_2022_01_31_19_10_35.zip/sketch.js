function setup() {
  createCanvas(500, 500);
  background(220);
}

function draw() {
  stroke(50);

  fill(230, 170, 161);
  triangle(112, 251, 190, 400, 340, 295); //Cheek
  triangle(186, 265, 360, 240, 340, 295); //Left Eye

  fill(207, 151, 145);
  triangle(225, 171, 360, 240, 118, 185); //Right half
  triangle(190, 400, 344, 349, 340, 295); //Left Jaw
  triangle(112, 251, 215, 208, 170, 365); //Right Cheek

  fill(230, 170, 161);
  triangle(186, 265, 118, 185, 360, 240); //Forehead
  triangle(205, 240, 192, 283, 236, 275); //Left nose

  fill(184, 134, 129);
  triangle(118, 185, 112, 251, 186, 265); //Right Eye

  triangle(190, 400, 145, 382, 112, 251); //Right jaw
  triangle(169, 361, 145, 382, 190, 400); //Chin

  triangle(205, 240, 192, 283, 186, 264); //Right nose

  //Mouth

  // noStroke()
  fill(120, 84, 76);
  triangle(156, 322, 212, 338, 175, 338); //Upper Lips
  triangle(156, 322, 185, 330, 171, 319);
  triangle(171, 326, 212, 338, 196, 325); //Lower Lip

  //Glasses
  curve(195, 244, 231, 251); // Creates a frame
  fill(192, 192, 192);
  translate(207, 238);
  rotate(0.08);
  ellipse(-45, 0, 70, 60);
  ellipse(61, 12, 70, 60);

  fill(100); //Gives a grey shade to the glass
  ellipse(-45, 0, 65, 55);
  ellipse(61, 12, 65, 55);

  arc(-45, 0, 65, 55, 0, PI + QUARTER_PI, CHORD); //A reflection?
  arc(61, 12, 65, 55, 0, PI + QUARTER_PI, CHORD);
}

function mouseClicked() {
  print("(" + mouseX + ", " + mouseY + ")"); //Simple tool to print the X and Y coordinates in console 
}
